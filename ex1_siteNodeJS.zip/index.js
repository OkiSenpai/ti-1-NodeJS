const express = require('express');
const app = express();

// Dossier avec les ressources statiques
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.render('accueil.ejs',{titrePage:"Bruxelles - Accueil"});
});

app.get('/geo', (req, res) => {
  res.render('geographie.ejs',{titrePage:"Bruxelles - Géographie"});
});

app.get('/hist', (req, res) => {
  res.render('histoire.ejs',{titrePage:"Bruxelles - Histoire"});
});

app.get('/cult', (req, res) => {
  res.render('culture.ejs',{titrePage:"Bruxelles - Culture"});
});

app.get('/gal', (req, res) => {
  res.render('galerie.ejs',{titrePage:"Bruxelles - Galerie"});
});

app.get('/form', (req, res) => {
  res.render('contact.ejs',{titrePage:"Bruxelles - Contact"});
});

app.get('/link', (req, res) => {
  res.render('liens.ejs',{titrePage:"Bruxelles - Liens"});
});

// Autre page non prévue -> Erreur 404
app.use((req,res,next) => {
    res.status(404).render('page-404.ejs',{titrePage:"Erreur 404"});
});

// Config serveur
const port = 3000;
app.listen(port, () => {
  console.log(`Serveur démarré, écoute sur le port ${port}`);
})